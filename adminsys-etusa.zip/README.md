# AdminSYS — ETUSA Cartographie

Application d’administration : API REST PHP 8.2/PDO_SQLSRV et interface Angular 18 responsive en français.

## Hypothèses de schéma

Le schéma reçu confirme `AdminSYS(IdSYS, Nom, Prenom, Password)`, `Direction(ID, Code, Nom, Actif)`, `PROFIL(IDPROF, CODE, LIBELLE, IDDIRECTION, ACC_CARTE, ACC_APP)` et `REF_PROFIL(ID_REFPROFIL, CODE_PROFIL, CODE_REFERENCE, ACC_AJOUT, ACC_MODIF, ACC_SUPP)`. Les DDL de `UTILISATEUR` et `REFERENCE` étaient tronqués; leurs colonnes supposées restent configurables dans `backend/src/Config.php`. Le backend utilise la nouvelle colonne `Login` comme identifiant et `Password` pour le hash. Le script `database/adminsys-password-hash.sql` élargit `Password` en NVARCHAR(255), nécessaire pour les mots de passe hachés. `Login` est obligatoire dans le schéma fourni; son unicité est recommandée si chaque administrateur doit avoir un identifiant distinct.

`REF_PROFIL` associe un profil à une référence avec trois autorisations binaires. Les accès application/carte sont aussi conservés dans PROFIL. Les directions sont désactivées au lieu d’être supprimées.

## Installation

1. Installer PHP 8.2+, extensions PDO_SQLSRV/SQLSRV, SQL Server, Node.js 20+ et Angular CLI 18.
2. Copier `backend/.env.example` vers `backend/.env`; saisir serveur, base, identifiants SQL et clé APP_SECRET d’au moins 32 caractères.
3. Pointer Apache/Nginx vers `backend/public`. En développement : `php -S 127.0.0.1:8080 -t backend/public backend/public/index.php`.
4. Créer le compte initial : `php backend/scripts/create-admin.php LOGIN NOM PRENOM 'mot-de-passe-de-12-caracteres'`.
5. Dans `frontend`, exécuter `npm install` puis `npm start`.
6. Vérifier les mappings de `Config.php`. Le script `database/recommended-constraints.sql` est facultatif; vérifier les doublons avant de l’exécuter.

## API

`POST /api/auth/login`; `GET /api/dashboard`; CRUD JSON sur `/api/directions`, `/api/profils`, `/api/utilisateurs`, `/api/references`, `/api/ref-profils`; `GET /api/permissions`. Les routes privées exigent `Authorization: Bearer <token>`. Limiter l’origine CORS, imposer HTTPS et utiliser un compte SQL de privilèges minimaux. Les mots de passe sont stockés par `password_hash()` et vérifiés avec `password_verify()`.
