<?php
declare(strict_types=1);
require dirname(__DIR__).'/src/Config.php'; require dirname(__DIR__).'/src/Api.php';
header('X-Content-Type-Options: nosniff');
try{(new \AdminSys\Api(\AdminSys\Config::load()))->run();}catch(Throwable $e){error_log($e);http_response_code(500);header('Content-Type: application/json; charset=utf-8');echo json_encode(['error'=>'Service indisponible']);}
